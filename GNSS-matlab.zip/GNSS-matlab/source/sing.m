% sing.m
clear; clc;

% Параметры
prn = 1; % Номер супутника (PRN 1)
signal_type = 'L1CA'; % Тип сигналу
fs = 5e6; % Частота дискретизації
n_periods = 10; % Кількість періодів (10 секунд)

% Перевірка шляху до функцій
addpath('D:\matlab\GNSS-matlab'); % Вкажіть ваш реальний шлях до репозиторію

% Перевірка наявності codes_L1CA.mat
if ~exist('codes_L1CA.mat', 'file')
    prn_list = 1:32; % Генерація кодів для всіх PRN
    codes = GNSScodegen(prn_list, 'L1CA', 0);
    save('codes_L1CA.mat', 'codes');
end

% Генерація сигналу
[I, Q] = GNSSsignalgen(prn, signal_type, fs, n_periods);

% Комбінування I і Q (для L1CA Q зазвичай нульова)
signal = I; % Для L1CA використовується тільки I-компонента

% Налаштування для збереження у .bin
filename = 'gnss_signal_prn1.bin'; % Ім'я файлу
fid = fopen(filename, 'w'); % Відкриття файлу для запису
fwrite(fid, signal, 'float32'); % Запис I-компоненти у форматі float32
fclose(fid);

% Модуляція з проміжною частотою (сегментація)
if_freq = 4.092e6; % Проміжна частота
segment_size = 1e4; % 0.002 секунди = 10,000 зразків
fid = fopen('gnss_signal_prn1_with_if.bin', 'w');
for i = 1:segment_size:length(I)
    idx_end = min(i + segment_size - 1, length(I));
    segment_length = idx_end - i + 1;
    t = single((0:segment_length-1) / fs); % Часова шкала для сегмента
    disp(['i: ' num2str(i) ', idx_end: ' num2str(idx_end) ', t length: ' num2str(length(t)) ', I segment length: ' num2str(length(I(i:idx_end)))]);
    if ~isempty(t) && length(t) == length(I(i:idx_end))
        segment = I(i:idx_end) .* cos(2 * pi * if_freq * t);
        fwrite(fid, segment, 'float32');
    else
        disp('Size mismatch detected!');
    end
end
fclose(fid);

% Візуалізація
figure;
subplot(2,1,1);
plot(I(1:1000)); % Первые 1000 сэмплов I-компоненты
title(['Generated GNSS Signal (I-component) for GPS L1 C/A, PRN ' num2str(prn)]);
xlabel('Samples'); ylabel('Amplitude');

subplot(2,1,2);
plot(Q(1:1000)); % Первые 1000 сэмплов Q-компоненты (для L1CA ожидается 0)
title(['Generated GNSS Signal (Q-component) for GPS L1 C/A, PRN ' num2str(prn)]);
xlabel('Samples'); ylabel('Amplitude');

% Сохранение результату
save('gnss_signal_prn1.mat', 'I', 'Q');

% Перевірка зчитування
fid = fopen('gnss_signal_prn1.bin', 'r');
signal_read = fread(fid, 'float32');
fclose(fid);
figure; plot(signal_read(1:1000)); title('Read Signal from .bin');