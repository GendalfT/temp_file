#ifndef GPSSIM_H
#define GPSSIM_H

//#define FLOAT_CARR_PHASE // Higher CPU, smoother carrier phase.

#define TRUE (1)
#define FALSE (0)

#define MAX_CHAR (100)
#define MAX_SAT (32)
#define MAX_CHAN (16)
#ifndef USER_MOTION_SIZE
#define USER_MOTION_SIZE (3000)
#endif
#define STATIC_MAX_DURATION (86400)

#define N_SBF (5)
#define N_DWRD_SBF (10)
#define N_DWRD ((N_SBF+1)*N_DWRD_SBF)
#define CA_SEQ_LEN (1023)

#define SECONDS_IN_WEEK 604800.0
#define SECONDS_IN_HALF_WEEK 302400.0
#define SECONDS_IN_DAY 86400.0
#define SECONDS_IN_HOUR 3600.0
#define SECONDS_IN_MINUTE 60.0

#define GM_EARTH 3.986005e14
#define OMEGA_EARTH 7.2921151467e-5
#define PI 3.1415926535898

#define WGS84_RADIUS 6378137.0
#define WGS84_ECCENTRICITY 0.0818191908426

#define R2D 57.2957795131
#define SPEED_OF_LIGHT 2.99792458e8
#define LAMBDA_L1 0.190293672798365

#define CARR_FREQ (1575.42e6)
#define CODE_FREQ (1.023e6)
#define CARR_TO_CODE (1.0/1540.0)

#define SC01 (1)
#define SC08 (8)
#define SC16 (16)

#define EPHEM_ARRAY_SIZE (15)

/* ==== Multi-GNSS additions ==== */
typedef enum { SYS_GPS = 0, SYS_GAL = 1 } sys_t;

typedef struct {
    double phase;  /* [0,1) */
    double dphi;   /* subcarrier phase step per sample */
} boc_state_t;
/* ============================== */

typedef struct {
    int week;
    double sec;
} gpstime_t;

typedef struct {
    int y, m, d, hh, mm;
    double sec;
} datetime_t;

typedef struct {
    int vflg;
    datetime_t t;
    gpstime_t toc, toe;
    int iodc, iode;
    double deltan, cuc, cus, cic, cis, crc, crs;
    double ecc, sqrta, m0, omg0, inc0, aop, omgdot, idot;
    double af0, af1, af2;
    double tgd;
    int svhlth, codeL2;
    /* working */
    double n, sq1e2, A, omgkdot;
} ephem_t;

typedef struct {
    int enable, vflg;
    double alpha0, alpha1, alpha2, alpha3;
    double beta0, beta1, beta2, beta3;
    double A0, A1;
    int dtls, tot, wnt, dtlsf, dn, wnlsf;
    int leapen;
} ionoutc_t;

typedef struct {
    gpstime_t g;
    double range;
    double rate;
    double d;
    double azel[2];
    double iono_delay;
} range_t;

typedef struct {
    /* NEW: system & RF */
    sys_t  sys;
    double f_rf;

    int prn;

    /* Codes */
    int  ca[CA_SEQ_LEN]; /* GPS C/A (0/1) */
    int* code;           /* generic primary code (�1) */
    int  code_len;
    int  codes_per_bit;

    double f_carr;
    double f_code;
#ifdef FLOAT_CARR_PHASE
    double        carr_phase;
#else
    unsigned int  carr_phase;
    int           carr_phasestep;
#endif
    double code_phase;

    gpstime_t g0;
    unsigned long sbf[5][N_DWRD_SBF];
    unsigned long dwrd[N_DWRD];
    int iword, ibit, icode;
    int dataBit; /* �1 */
    int codeCA;  /* �1 */
    double azel[2];
    range_t rho0;

    /* NEW: BOC state (Galileo) */
    boc_state_t boc;
} channel_t;

/* used by gal_codes.c */
void codegen(int* ca, int prn);

#endif /* GPSSIM_H */
/* legacy LFSR tap masks (��� GPS � Galileo code generators) */
#define POW2_M5   (1<<5)
#define POW2_M6   (1<<6)
#define POW2_M7   (1<<7)
#define POW2_M8   (1<<8)
#define POW2_M9   (1<<9)
#define POW2_M10  (1<<10)
#define POW2_M11  (1<<11)
#define POW2_M17  (1<<17)
#define POW2_M18  (1<<18)
#define POW2_M19  (1<<19)
#define POW2_M20  (1<<20)
#define POW2_M23  (1<<23)
#define POW2_M24  (1<<24)
#define POW2_M25  (1<<25)
#define POW2_M26  (1<<26)
#define POW2_M27  (1<<27)
#define POW2_M28  (1<<28)
#define POW2_M29  (1<<29)
#define POW2_M30  (1<<30)
#define POW2_M31  (1<<31)
#define POW2_M32  (1<<32)
#define POW2_M33  (1<<33)
#define POW2_M38  (1<<38)
#define POW2_M39  (1<<39)
#define POW2_M40  (1<<40)
#define POW2_M41  (1<<41)
#define POW2_M42  (1<<42)
#define POW2_M43  (1<<43)
#define POW2_M48  (1<<48)
#define POW2_M49  (1<<49)
#define POW2_M50  (1<<50)
#define POW2_M55  (1<<55)
