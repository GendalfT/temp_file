#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdlib.h>
#include "galileo.h"

/* codegen() � ��� ���� � gpssim.c */
extern void codegen(int* ca, int prn);

static void map_gps_ca_to_4092(int gps_prn, int* out4092)
{
    int ca[CA_SEQ_LEN];
    codegen(ca, gps_prn);
    for (int k = 0; k < 4; k++)
        for (int i = 0; i < CA_SEQ_LEN; i++)
            out4092[k * CA_SEQ_LEN + i] = (ca[i] ? +1 : -1);
}

int gal_e1b_primary_code(int prn, int* out4092)
{
    if (!out4092 || prn<1 || prn>GAL_MAX_SAT) return 0;
    map_gps_ca_to_4092((prn % 32) + 1, out4092);
    return 1;
}

int gal_e1c_primary_code(int prn, int* out4092)
{
    if (!out4092 || prn<1 || prn>GAL_MAX_SAT) return 0;
    map_gps_ca_to_4092(((prn + 7) % 32) + 1, out4092);
    return 1;
}
