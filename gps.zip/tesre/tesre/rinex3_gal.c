#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "galileo.h"

#define MAX_LINE 160

#ifdef _MSC_VER
#define STRNCOPY(dst, src, n) strncpy_s((dst), (n), (src), _TRUNCATE)
#else
#define STRNCOPY(dst, src, n) do { strncpy((dst), (src), (n)); (dst)[(n)-1]='\0'; } while(0)
#endif

/* you already have these in gpssim.c; declare them here */
extern void date2gps(const datetime_t* t, gpstime_t* g);
extern double subGpsTime(gpstime_t g1, gpstime_t g0);

static double fld(const char* s, int i) {
    int off = 4 + i * 19;
    char buf[24]; int k = 0;
    if ((int)strlen(s) < off + 1) return 0.0;
    while (k < 19 && s[off + k]) { buf[k] = s[off + k]; k++; }
    buf[k] = '\0';
    for (int j = 0; buf[j]; ++j) if (buf[j] == 'D') buf[j] = 'E';
    return atof(buf);
}

int readRinexNavAllGal(galeph_t eph[][GAL_MAX_SAT], const char* fname)
{
    FILE* fp = fopen(fname, "rt");
    if (!fp) return -1;

    char line[MAX_LINE];
    int ieph = 0;

    for (int i = 0; i < EPHEM_ARRAY_SIZE; i++)
        for (int s = 0; s < GAL_MAX_SAT; s++) eph[i][s].base.vflg = 0;

    /* header */
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "END OF HEADER")) break;
    }

    gpstime_t g0 = { -1, 0.0 };

    while (fgets(line, sizeof(line), fp)) {
        if (line[0] != 'E') continue; /* only Galileo lines */
        int prn = atoi(&line[1]);
        if (prn<1 || prn>GAL_MAX_SAT) { for (int k = 0; k < 7; k++) fgets(line, sizeof(line), fp); continue; }
        int sv = prn - 1;

        datetime_t t; char tmp[8];
        STRNCOPY(tmp, line + 4, 4);  t.y = atoi(tmp); if (t.y < 100) t.y += 2000;
        STRNCOPY(tmp, line + 9, 2);  t.m = atoi(tmp);
        STRNCOPY(tmp, line + 12, 2); t.d = atoi(tmp);
        STRNCOPY(tmp, line + 15, 2); t.hh = atoi(tmp);
        STRNCOPY(tmp, line + 18, 2); t.mm = atoi(tmp);
        STRNCOPY(tmp, line + 21, 2); t.sec = atof(tmp);

        double af0 = fld(line, 1), af1 = fld(line, 2), af2 = fld(line, 3);

        char l2[MAX_LINE], l3[MAX_LINE], l4[MAX_LINE], l5[MAX_LINE], l6[MAX_LINE], dummy[MAX_LINE];
        if (!fgets(l2, sizeof(l2), fp)) break;
        if (!fgets(l3, sizeof(l3), fp)) break;
        if (!fgets(l4, sizeof(l4), fp)) break;
        if (!fgets(l5, sizeof(l5), fp)) break;
        if (!fgets(l6, sizeof(l6), fp)) break;
        fgets(dummy, sizeof(dummy), fp); /* L7 optional */
        fgets(dummy, sizeof(dummy), fp); /* L8 optional */

        galeph_t* E = &eph[ieph][sv];
        memset(E, 0, sizeof(*E));
        E->base.vflg = 1;
        E->base.t = t;
        date2gps(&t, &E->base.toc);
        E->base.toe = E->base.toc;
        E->base.af0 = af0; E->base.af1 = af1; E->base.af2 = af2;

        E->iod_nav = (int)fld(l2, 0);
        E->base.crs = fld(l2, 1);
        E->base.deltan = fld(l2, 2);
        E->base.m0 = fld(l2, 3);

        E->base.cuc = fld(l3, 0);
        E->base.ecc = fld(l3, 1);
        E->base.cus = fld(l3, 2);
        E->base.sqrta = fld(l3, 3);

        E->base.toe.sec = fld(l4, 0);
        E->base.cic = fld(l4, 1);
        E->base.omg0 = fld(l4, 2);
        E->base.cis = fld(l4, 3);

        E->base.inc0 = fld(l5, 0);
        E->base.crc = fld(l5, 1);
        E->base.aop = fld(l5, 2);
        E->base.omgdot = fld(l5, 3);

        E->base.idot = fld(l6, 0);
        E->bgd_e1e5a = fld(l6, 1);
        E->bgd_e1e5b = fld(l6, 2);

        E->base.A = E->base.sqrta * E->base.sqrta;
        E->base.n = sqrt(GM_EARTH / (E->base.A * E->base.A * E->base.A)) + E->base.deltan;
        E->base.sq1e2 = sqrt(1.0 - E->base.ecc * E->base.ecc);
        E->base.omgkdot = E->base.omgdot - OMEGA_EARTH;

        /* MVP: reuse tgd to carry BGD (E1/E5a) so computeRange subtracts it */
        E->base.tgd = E->bgd_e1e5a;
        E->base.svhlth = 0; E->base.codeL2 = 0;
        E->base.toe.week = E->base.toc.week;

        if (g0.week == -1) g0 = E->base.toc;
        if (subGpsTime(E->base.toc, g0) > SECONDS_IN_HOUR) {
            g0 = E->base.toc;
            ieph++;
            if (ieph >= EPHEM_ARRAY_SIZE) break;
        }
    }

    fclose(fp);
    if (ieph == 0) ieph = 1;
    return ieph;
}
