#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "galileo.h"

/* ������� ������� �� gpssim.c */
extern int checkSatVisibility(ephem_t eph, gpstime_t g, double* xyz, double elvMask, double* azel);
extern void computeRange(range_t* rho, ephem_t eph, ionoutc_t* ionoutc, gpstime_t g, double xyz[]);

int allocateChannelGal(channel_t* chan, galeph_t* eph, gpstime_t grx, double* xyz, double elvMask)
{
    int added = 0;
    for (int sv = 0; sv < GAL_MAX_SAT; sv++) {
        if (eph[sv].base.vflg != 1) continue;

        double azel[2];
        if (checkSatVisibility(eph[sv].base, grx, xyz, 0.0, azel) != 1) continue;

        /* ��������� ���� */
        int i;
        for (i = 0; i < MAX_CHAN; i++) if (chan[i].prn == 0) break;
        if (i == MAX_CHAN) break;

        chan[i].sys = SYS_GAL;
        chan[i].prn = sv + 1;
        chan[i].f_rf = GAL_E1_FREQ_HZ;
        chan[i].f_code = GAL_E1_CODE_HZ;
        chan[i].code_len = GAL_E1_CODELEN;
        chan[i].codes_per_bit = 1; /* 4 �� = 1 ��� @ 250 bps */
        chan[i].azel[0] = azel[0]; chan[i].azel[1] = azel[1];

        chan[i].code = (int*)calloc(chan[i].code_len, sizeof(int));
        if (!chan[i].code || !gal_e1b_primary_code(chan[i].prn, chan[i].code)) {
            if (chan[i].code) { free(chan[i].code); chan[i].code = NULL; }
            chan[i].prn = 0; continue;
        }

        chan[i].dataBit = +1; /* MVP: ������ ����� */
        chan[i].icode = chan[i].ibit = chan[i].iword = 0;
        chan[i].code_phase = 0.0;
#ifdef FLOAT_CARR_PHASE
        chan[i].carr_phase = 0.0;
#else
        chan[i].carr_phase = 0; chan[i].carr_phasestep = 0;
#endif
        chan[i].boc.phase = 0.0; chan[i].boc.dphi = 0.0;

        ionoutc_t noiono = { 0 };
        computeRange(&chan[i].rho0, eph[sv].base, &noiono, grx, xyz);
        added++;
    }
    return added;
}
