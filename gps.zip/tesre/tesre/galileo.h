#ifndef GALILEO_H
#define GALILEO_H

#include "gpssim.h"

#define GAL_MAX_SAT     36
#define GAL_E1_FREQ_HZ  1575.42e6
#define GAL_E1_CODE_HZ  1.023e6
#define GAL_E1_SUB_HZ   1.023e6   /* BOC(1,1) subcarrier */
#define GAL_E1_CODELEN  4092
#define GAL_E1_BPS      250

typedef struct {
    ephem_t base;        /* reuse ephem_t; BGD ����� � base.tgd */
    double bgd_e1e5a;
    double bgd_e1e5b;
    int    iod_nav;
} galeph_t;

/* API */
int readRinexNavAllGal(galeph_t eph[][GAL_MAX_SAT], const char* fname);
int gal_e1b_primary_code(int prn, int* out4092);
int gal_e1c_primary_code(int prn, int* out4092);

#endif
