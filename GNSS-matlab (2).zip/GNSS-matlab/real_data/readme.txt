Get the capture files from https://mega.nz/#F!aCxChKbA!HKGQC1X2CDfN-nmkovVjyg
and unzip them in the "captures" folder