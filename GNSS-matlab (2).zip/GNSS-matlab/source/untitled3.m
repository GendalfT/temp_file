% gps_prn01_to_bin.m
% Один супутник GPS L1 C/A (PRN=1), baseband (IF=0), без навігаційних бітів.
% Вихід: raw .bin, інтерлів I/Q, тип int16, little-endian.
clear; clc;

%% Параметри сигналу
PRN        = 1;           % G1
FS         = 4.092e6;     % семпли/с (рівно 4 семпли на чип при 1.023 Мчип/с)
DURATION_S = 2.0;         % тривалість файлу
AMP_Q11    = 1800;        % амплітуда (SC16_Q11 ≈ ±2047; не сатуруємо)

% OPTIONAL: якщо хочеш IF (у самому файлі) і/або допплер — задай нижче,
% і увімкни блок "IF/Doppler" далі.
USE_IF     = false;       % залиш true, якщо потрібен IF усередині .bin
IF_HZ      = 1.25e6;      % приклад IF (за потреби)
DOPPLER_HZ = 1000;        % приклад допплера (за потреби)

%% Перевірка узгодження з чипрейтом
CHIPRATE = 1.023e6;                      % L1 C/A
SPC = FS / CHIPRATE;                     % samples per chip
assert(abs(SPC - round(SPC)) < 1e-9, 'FS має давати ціле SPC (FS/1.023e6).');
SPC = round(SPC);

%% 1) C/A код для PRN=1 (1023 чипи, значення ±1)
ca = ca_prn1();                          % локальна ф-ція нижче

%% 2) Побудова потоку чипів на потрібну тривалість
ms_total   = round(DURATION_S * 1000);   % C/A повторюється кожну мс
chips_ms   = repmat(ca, ms_total, 1);    % послідовні мілісекунди
I_chips    = chips_ms;                   % BPSK на I
Q_chips    = zeros(size(I_chips));       % Q=0

%% 3) Апсемплінг: SPC семплів на чип (Zero-Order Hold)
I = repelem(I_chips, SPC);
Q = repelem(Q_chips, SPC);

%% OPTIONAL: IF/Doppler усередині файлу .bin (вимкнено за замовчуванням)
if USE_IF
    N = numel(I);
    t = (0:N-1).' / FS;
    % Мікшування в комплексну експоненту (I/Q):
    % BPSK(I) переносимо на IF + DOPPLER: s(t) = I(t) * exp(j*2π f t)
    mix = exp(1j*2*pi*(IF_HZ + DOPPLER_HZ)*t);
    s   = complex(I, Q) .* mix;
else
    s   = complex(I, Q);  % baseband (0 IF)
end

%% 4) Масштабування під int16 (SC16_Q11 діапазон ~±2047)
ii = int16(max(min(round(real(s)*AMP_Q11),  2047), -2048));
qq = int16(max(min(round(imag(s)*AMP_Q11),  2047), -2048));

%% 5) Інтерлів I/Q та запис у .bin (little-endian)
iq = zeros(2*numel(ii), 1, 'int16');
iq(1:2:end) = ii;
iq(2:2:end) = qq;

fname = 'gps_prn01.bin';
fid = fopen(fname, 'wb', 'ieee-le');   % явне little-endian
fwrite(fid, iq, 'int16');
fclose(fid);
fprintf('Saved %s (samples: %d I/Q pairs, FS=%.3f MHz)\n', fname, numel(ii), FS/1e6);

%% 6) Швидка перевірка рівня та кількох точок
r = double(ii(1:10));
fprintf('I[1:10] = '); fprintf('%d ', r); fprintf('\n');


function c = ca_prn1()
% C/A PRN1: реалізація за IS-GPS-200 через два регістри:
% G1 (x^10 + x^3 + 1), G2 (x^10 + x^9 + x^8 + x^6 + x^3 + x^2 + 1)
% Вихідний PRN1: G1 ⊕ (G2 taps 2,6). Ми працюємо в алгебрі ±1, тому XOR -> множення.
    c = zeros(1023,1);
    g1 = -ones(1,10);  % -1 еквівалент "1" у двійковій (зручно для множення)
    g2 = -ones(1,10);
    for i = 1:1023
        g2_out = g2(2) * g2(6);                  % taps для PRN1
        c(i)   = g1(10) * g2_out;                % вихід C/A
        g1_fb  = g1(3) * g1(10);                 % зворотній зв'язок G1
        g2_fb  = g2(2)*g2(3)*g2(6)*g2(8)*g2(9)*g2(10); % зворотній зв'язок G2
        g1     = [g1_fb, g1(1:9)];
        g2     = [g2_fb, g2(1:9)];
    end
end
