% generate_gps_g30.m - Генерация GPS L1 C/A сигнала для PRN 30 (G30)
% Использует ручную генерацию C/A-кода, если GNSScodegen не работает

% Настройка пути к GNSS-matlab (укажи свой путь)
% addpath('/path/to/GNSS-matlab');  % Раскомментируй, если GNSScodegen работает

% Параметры сигнала
signal_type = 'L1CA';  % Тип сигнала: L1 C/A
prn = 30;              % PRN спутника G30
fs = 20e6;             % Частота дискретизации (20 МГц)
duration = 0.02;       % Длительность сигнала (20 мс)
chip_rate = 1.023e6;   % Чип-рейт для L1 C/A

% Ручная генерация C/A-кода
function ca_code = generateCAcode(prn)
    g1 = ones(1, 10);  % G1 регистр
    g2 = ones(1, 10);  % G2 регистр
    ca_code = zeros(1, 1023);
    phase_select = [6, 8];  % Для PRN 30
    for i = 1:1023
        g1_out = g1(10);
        g1 = [mod(g1(3) + g1(10), 2), g1(1:end-1)];
        g2_out = g2(10);
        g2 = [mod(g2(2) + g2(3) + g2(6) + g2(8) + g2(9) + g2(10), 2), g2(1:end-1)];
        ca_code(i) = mod(g1_out + g2(phase_select(1)) + g2(phase_select(2)), 2);
    end
    ca_code = 1 - 2 * ca_code;  % +1/-1
end

% Генерация PRN-кода
try
    prn_code = generateCAcode(30);  % Ручная генерация
    disp(['PRN-код сгенерирован, длина: ', num2str(length(prn_code))]);
catch e
    disp('Ошибка в генерации PRN-кода:');
    disp(e.message);
    return;
end

% Генерация сэмплированного сигнала
t = (0:1/fs:duration-1/fs)';  % Временной вектор
code_repeated = repmat(prn_code, ceil(duration * chip_rate / length(prn_code)), 1);
code_repeated = code_repeated(1:floor(duration * chip_rate));
code_samples = interp1((0:length(code_repeated)-1)/chip_rate, code_repeated, t, 'previous');
carrier = cos(2 * pi * 1575.42e6 * t);  % Несущая L1
signal = code_samples .* carrier;  % Модуляция

% Масштабирование и сохранение в .bin
signal_int16 = int16(signal * 32767);
fid = fopen('gps_g30_signal.bin', 'wb');
fwrite(fid, signal_int16, 'int16');
fclose(fid);

disp('Сигнал для G30 сохранён в gps_g30_signal.bin');